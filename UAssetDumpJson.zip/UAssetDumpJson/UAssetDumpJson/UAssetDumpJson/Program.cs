﻿using System;
using System.IO;
using System.Linq;
using System.Reflection;

class Program
{
    static int Main(string[] args)
    {
        Console.OutputEncoding = System.Text.Encoding.UTF8;

        if (args.Length < 1)
        {
            Console.Error.WriteLine("用法: UAssetDumpJson <path\\file.uasset> [--usmap <path\\Mappings.usmap>]");
            return 2;
        }

        // 参数
        string uassetPath = args[0];
        string? usmapPath = null;
        for (int i = 1; i < args.Length; i++)
        {
            if (args[i].Equals("--usmap", StringComparison.OrdinalIgnoreCase) && i + 1 < args.Length)
            {
                usmapPath = args[i + 1];
                i++;
            }
        }

        if (!File.Exists(uassetPath))
        {
            Console.Error.WriteLine("找不到 .uasset: " + uassetPath);
            return 3;
        }
        if (usmapPath != null && !File.Exists(usmapPath))
        {
            Console.Error.WriteLine("找不到 .usmap: " + usmapPath);
            return 4;
        }

        try
        {
            // 装载 UAssetAPI（如需可改为绝对路径 Assembly.LoadFrom）
            var asm = Assembly.LoadFrom(Path.Combine(AppContext.BaseDirectory, "UAssetAPI.dll"));
            var uassetType = asm.GetType("UAssetAPI.UAsset", throwOnError: true)!;

            // 工具
            Type? FindType(string name) =>
                asm.GetType(name, throwOnError: false) ??
                asm.GetTypes().FirstOrDefault(t =>
                    t.FullName?.EndsWith("." + name, StringComparison.Ordinal) == true ||
                    t.Name == name);

            // 不用 FieldInfo.GetValue(null)，用 Enum.Parse 避免 TargetException
            object PickEnum(Type enumType, params string[] prefer)
            {
                var names = Enum.GetNames(enumType);
                foreach (var want in prefer)
                {
                    var hit = names.FirstOrDefault(n => string.Equals(n, want, StringComparison.OrdinalIgnoreCase));
                    if (hit != null) return Enum.Parse(enumType, hit);
                }
                var fuzzy = names.FirstOrDefault(n =>
                    n.Contains("UE4_26", StringComparison.OrdinalIgnoreCase) ||
                    n.Contains("4_26", StringComparison.OrdinalIgnoreCase));
                if (fuzzy != null) return Enum.Parse(enumType, fuzzy);

                var latest = names.FirstOrDefault(n => n.Contains("LATEST", StringComparison.OrdinalIgnoreCase));
                if (latest != null) return Enum.Parse(enumType, latest);

                return Enum.Parse(enumType, names.First());
            }

            // 类型
            var EngineVersion = FindType("UAssetAPI.UnrealTypes.EngineVersion") ?? FindType("EngineVersion");
            var ObjectVersion = FindType("UAssetAPI.UnrealTypes.ObjectVersion") ?? FindType("ObjectVersion");
            var ObjectVersionUE5 = FindType("UAssetAPI.UnrealTypes.ObjectVersionUE5") ?? FindType("ObjectVersionUE5");
            var Usmap = FindType("UAssetAPI.Unversioned.Usmap") ?? FindType("Usmap");
            var UsmapBinaryReader = FindType("UAssetAPI.Unversioned.UsmapBinaryReader") ?? FindType("UsmapBinaryReader");
            var AssetBinaryReader = FindType("UAssetAPI.AssetBinaryReader") ?? FindType("AssetBinaryReader");
            var CustomSerializationFlags = FindType("UAssetAPI.CustomSerializationFlags") ?? FindType("CustomSerializationFlags");

            object? engineVer = EngineVersion != null ? PickEnum(EngineVersion, "VER_UE4_26") : null;
            object? objVer = ObjectVersion != null ? PickEnum(ObjectVersion, "VER_UE4_26") : null;
            object? objVer5 = ObjectVersionUE5 != null ? PickEnum(ObjectVersionUE5, "VER_UE5_LATEST") : null;

            // csf 既可能是枚举也可能是类
            object? csf = null;
            if (CustomSerializationFlags != null)
            {
                csf = CustomSerializationFlags.IsEnum
                    ? Enum.ToObject(CustomSerializationFlags, 0)
                    : Activator.CreateInstance(CustomSerializationFlags);
            }

            // ===== 关键新增：是否存在同名 .uexp（存在则启用外部数据读取） =====
            bool hasUexp = File.Exists(Path.ChangeExtension(uassetPath, ".uexp"));

            // ------- 读取 .usmap（如果提供） -------
            object? usmap = null;
            if (usmapPath != null && Usmap != null)
            {
                Console.WriteLine("[USMAP] file = " + usmapPath);
                Console.WriteLine("[USMAP] Usmap type = " + Usmap.FullName);
                Console.WriteLine("[USMAP] UsmapBinaryReader type = " + (UsmapBinaryReader?.FullName ?? "(null)"));

                byte[] data = File.ReadAllBytes(usmapPath);
                Console.WriteLine("[USMAP] size = " + data.Length);

                // 1) 优先 Usmap(string path)
                try
                {
                    var ctorPath = Usmap.GetConstructor(new[] { typeof(string) });
                    if (ctorPath != null)
                    {
                        usmap = ctorPath.Invoke(new object?[] { usmapPath });
                        Console.WriteLine("[USMAP] OK: ctor(string path)");
                    }
                }
                catch (TargetInvocationException tie)
                {
                    Console.WriteLine("[USMAP] ctor(string) inner: " + (tie.InnerException?.Message ?? tie.Message));
                    usmap = null;
                }
                catch (Exception e)
                {
                    Console.WriteLine("[USMAP] ctor(string) fail: " + e.GetType().Name + " - " + e.Message);
                    usmap = null;
                }

                // 2) 回退：Usmap(Stream)
                if (usmap == null)
                {
                    try
                    {
                        var ctorS = Usmap.GetConstructor(new[] { typeof(Stream) });
                        if (ctorS != null)
                        {
                            using var ms = new MemoryStream(data, writable: false);
                            usmap = ctorS.Invoke(new object?[] { ms });
                            Console.WriteLine("[USMAP] OK: ctor(Stream)");
                        }
                    }
                    catch (Exception e) { Console.WriteLine("[USMAP] ctor(Stream) fail: " + e.GetType().Name + " - " + e.Message); }
                }

                // 3) 回退：Usmap(byte[])
                if (usmap == null)
                {
                    try
                    {
                        var ctorB = Usmap.GetConstructor(new[] { typeof(byte[]) });
                        if (ctorB != null)
                        {
                            usmap = ctorB.Invoke(new object?[] { data });
                            Console.WriteLine("[USMAP] OK: ctor(byte[])");
                        }
                    }
                    catch (Exception e) { Console.WriteLine("[USMAP] ctor(byte[]) fail: " + e.GetType().Name + " - " + e.Message); }
                }

                // 4) 可选：静态工厂
                if (usmap == null)
                {
                    var factories = Usmap.GetMethods(BindingFlags.Public | BindingFlags.Static)
                        .Where(mi => mi.ReturnType == Usmap && mi.GetParameters().Length == 1)
                        .ToArray();

                    foreach (var m in factories)
                    {
                        var pt = m.GetParameters()[0].ParameterType;
                        try
                        {
                            if (pt == typeof(string)) { usmap = m.Invoke(null, new object?[] { usmapPath }); }
                            else if (pt == typeof(Stream)) { using var ms = new MemoryStream(data, false); usmap = m.Invoke(null, new object?[] { ms }); }
                            else if (pt == typeof(byte[])) { usmap = m.Invoke(null, new object?[] { data }); }
                            if (usmap != null) { Console.WriteLine("[USMAP] OK: static factory " + m.Name); break; }
                        }
                        catch (Exception e) { Console.WriteLine("[USMAP] factory fail: " + e.GetType().Name + " - " + e.Message); }
                    }
                }

                if (usmap == null)
                    throw new InvalidOperationException("无法从 .usmap 创建 Usmap 实例。");
            }
            // ------- 读取 .usmap 结束 -------

            // 构造 UAsset（优先使用含 usmap 的重载）
            object? asset = null;
            foreach (var ctor in uassetType.GetConstructors().OrderByDescending(c => c.GetParameters().Length))
            {
                var ps = ctor.GetParameters();
                if (ps.Length == 0) continue;

                try
                {
                    // (string, …)
                    if (ps[0].ParameterType == typeof(string))
                    {
                        var ctorArgs = new object?[ps.Length];
                        ctorArgs[0] = uassetPath;

                        bool ok = true;
                        for (int i = 1; i < ps.Length; i++)
                        {
                            var pt = ps[i].ParameterType;

                            if (pt == typeof(bool)) { ctorArgs[i] = hasUexp; continue; }  // ★ 改这里
                            if (EngineVersion != null && pt == EngineVersion) { ctorArgs[i] = engineVer!; continue; }
                            if (Usmap != null && pt == Usmap) { ctorArgs[i] = usmap; continue; }
                            if (CustomSerializationFlags != null && pt == CustomSerializationFlags) { ctorArgs[i] = csf!; continue; }
                            if (ObjectVersion != null && pt == ObjectVersion) { ctorArgs[i] = objVer!; continue; }
                            if (ObjectVersionUE5 != null && pt == ObjectVersionUE5) { ctorArgs[i] = objVer5!; continue; }

                            ok = false; break;
                        }
                        if (ok)
                        {
                            asset = ctor.Invoke(ctorArgs);
                            if (asset != null) break;
                        }
                    }

                    // (AssetBinaryReader, …)
                    if (asset == null && AssetBinaryReader != null && ps[0].ParameterType == AssetBinaryReader)
                    {
                        using var fs2 = File.OpenRead(uassetPath);
                        object? reader = null;

                        foreach (var rctor in AssetBinaryReader.GetConstructors())
                        {
                            var rps = rctor.GetParameters();
                            if (rps.Length >= 1 && rps[0].ParameterType == typeof(Stream))
                            {
                                var readerCtorArgs = new object?[rps.Length];
                                readerCtorArgs[0] = fs2;
                                for (int j = 1; j < rps.Length; j++)
                                {
                                    var rpt = rps[j].ParameterType;
                                    if (rpt.IsEnum) readerCtorArgs[j] = Enum.ToObject(rpt, 0);
                                    else if (rpt == typeof(long) || rpt == typeof(int)) readerCtorArgs[j] = 0;
                                    else readerCtorArgs[j] = null;
                                }
                                reader = rctor.Invoke(readerCtorArgs);
                                break;
                            }
                        }
                        if (reader == null) continue;

                        var ctorArgs2 = new object?[ps.Length];
                        ctorArgs2[0] = reader;

                        bool ok2 = true;
                        for (int i = 1; i < ps.Length; i++)
                        {
                            var pt = ps[i].ParameterType;
                            if (EngineVersion != null && pt == EngineVersion) { ctorArgs2[i] = engineVer!; continue; }
                            if (Usmap != null && pt == Usmap) { ctorArgs2[i] = usmap; continue; }
                            if (pt == typeof(bool)) { ctorArgs2[i] = hasUexp; continue; }  // ★ 以及这里
                            if (CustomSerializationFlags != null && pt == CustomSerializationFlags) { ctorArgs2[i] = csf!; continue; }
                            if (ObjectVersion != null && pt == ObjectVersion) { ctorArgs2[i] = objVer!; continue; }
                            if (ObjectVersionUE5 != null && pt == ObjectVersionUE5) { ctorArgs2[i] = objVer5!; continue; }

                            ok2 = false; break;
                        }
                        if (ok2)
                        {
                            asset = ctor.Invoke(ctorArgs2);
                            if (asset != null) break;
                        }
                    }
                }
                catch { /* 尝试下一个重载 */ }
            }

            if (asset == null)
            {
                var sigs = string.Join("\n  ", uassetType.GetConstructors()
                    .Select(c => $"({string.Join(", ", c.GetParameters().Select(p => p.ParameterType.Name))})"));
                throw new MissingMethodException("未能匹配到可用 UAsset 构造函数。构造器有：\n  " + sigs);
            }

            // 精确选择 SerializeJson/SerializeJSON 重载
            var serMethods = uassetType.GetMethods(BindingFlags.Instance | BindingFlags.Public)
                .Where(m => (m.Name == "SerializeJson" || m.Name == "SerializeJSON")
                         && m.ReturnType == typeof(string))
                .ToArray();

            var ser = serMethods.FirstOrDefault(m =>
            {
                var p = m.GetParameters();
                return p.Length == 1 && p[0].ParameterType == typeof(bool);
            }) ?? serMethods.FirstOrDefault(m => m.GetParameters().Length == 0);

            if (ser == null)
            {
                var list = string.Join("\n  ", serMethods.Select(m => $"{m.Name}({string.Join(", ", m.GetParameters().Select(p => p.ParameterType.Name))})"));
                throw new MissingMethodException("未找到可用的 JSON 序列化方法。候选：\n  " + (list == "" ? "(无)" : list));
            }

            string json = ser.GetParameters().Length == 1
                ? (string)(ser.Invoke(asset, new object?[] { true }) ?? "{}")
                : (string)(ser.Invoke(asset, Array.Empty<object?>()) ?? "{}");

            var outPath = Path.ChangeExtension(uassetPath, ".json");
            File.WriteAllText(outPath, json);
            Console.WriteLine("OK -> " + outPath);
            return 0;
        }
        catch (Exception ex)
        {
            Console.Error.WriteLine("导出失败: " + ex.GetType().Name + " - " + ex.Message);
            return 1;
        }
    }
}
