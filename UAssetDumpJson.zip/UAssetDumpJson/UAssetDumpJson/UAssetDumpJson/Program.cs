﻿using System;
using System.IO;
using System.Linq;
using System.Reflection;

class Program
{
    static int Main(string[] args)
    {
        Console.OutputEncoding = System.Text.Encoding.UTF8;

        if (args.Length < 1)
        {
            Console.Error.WriteLine("用法: UAssetDumpJson <path\\file.uasset> [--usmap <ignored>]");
            return 2;
        }

        // 参数：第一位是 uasset；其余参数全部忽略（包括 --usmap）
        string uassetPath = args[0];

        if (!File.Exists(uassetPath))
        {
            Console.Error.WriteLine("找不到 .uasset: " + uassetPath);
            return 3;
        }

        try
        {
            // 装载 UAssetAPI（如需可改为绝对路径 Assembly.LoadFrom）
            var asm = Assembly.LoadFrom(Path.Combine(AppContext.BaseDirectory, "UAssetAPI.dll"));
            var uassetType = asm.GetType("UAssetAPI.UAsset", throwOnError: true)!;

            // 工具
            Type? FindType(string name) =>
                asm.GetType(name, throwOnError: false) ??
                asm.GetTypes().FirstOrDefault(t =>
                    t.FullName?.EndsWith("." + name, StringComparison.Ordinal) == true ||
                    t.Name == name);

            object PickEnum(Type enumType, params string[] prefer)
            {
                var names = Enum.GetNames(enumType);
                foreach (var want in prefer)
                {
                    var hit = names.FirstOrDefault(n => string.Equals(n, want, StringComparison.OrdinalIgnoreCase));
                    if (hit != null) return Enum.Parse(enumType, hit);
                }
                var fuzzy = names.FirstOrDefault(n =>
                    n.Contains("UE4_26", StringComparison.OrdinalIgnoreCase) ||
                    n.Contains("4_26", StringComparison.OrdinalIgnoreCase));
                if (fuzzy != null) return Enum.Parse(enumType, fuzzy);

                var latest = names.FirstOrDefault(n => n.Contains("LATEST", StringComparison.OrdinalIgnoreCase));
                if (latest != null) return Enum.Parse(enumType, latest);

                return Enum.Parse(enumType, names.First());
            }

            // 常用类型（不加载/不使用 Usmap）
            var EngineVersion = FindType("UAssetAPI.UnrealTypes.EngineVersion") ?? FindType("EngineVersion");
            var ObjectVersion = FindType("UAssetAPI.UnrealTypes.ObjectVersion") ?? FindType("ObjectVersion");
            var ObjectVersionUE5 = FindType("UAssetAPI.UnrealTypes.ObjectVersionUE5") ?? FindType("ObjectVersionUE5");
            var AssetBinaryReader = FindType("UAssetAPI.AssetBinaryReader") ?? FindType("AssetBinaryReader");
            var CustomSerializationFlags = FindType("UAssetAPI.CustomSerializationFlags") ?? FindType("CustomSerializationFlags");
            var UsmapType = FindType("UAssetAPI.Unversioned.Usmap") ?? FindType("Usmap"); // 仅用于识别构造器参数类型

            object? engineVer = EngineVersion != null ? PickEnum(EngineVersion, "VER_UE4_26") : null;
            object? objVer = ObjectVersion != null ? PickEnum(ObjectVersion, "VER_UE4_26") : null;
            object? objVer5 = ObjectVersionUE5 != null ? PickEnum(ObjectVersionUE5, "VER_UE5_LATEST") : null;

            // csf 既可能是枚举也可能是类
            object? csf = null;
            if (CustomSerializationFlags != null)
            {
                csf = CustomSerializationFlags.IsEnum
                    ? Enum.ToObject(CustomSerializationFlags, 0)
                    : Activator.CreateInstance(CustomSerializationFlags);
            }

            // 是否存在同名 .uexp（存在则启用外部数据读取）
            bool hasUexp = File.Exists(Path.ChangeExtension(uassetPath, ".uexp"));

            // ========== 实例化 UAsset（无 usmap） ==========
            object? asset = null;

            // 先尝试 **不含 Usmap 参数** 的构造器，再退而求其次传 null 给含 Usmap 的构造器
            var ctors = uassetType
                .GetConstructors()
                .OrderByDescending(c =>
                {
                    // 排序键：不含 Usmap 优先，参数多的优先
                    bool containsUsmap = UsmapType != null && c.GetParameters().Any(p => p.ParameterType == UsmapType);
                    return (containsUsmap ? 0 : 1) * 1000 + c.GetParameters().Length;
                })
                .ToArray();

            foreach (var ctor in ctors)
            {
                var ps = ctor.GetParameters();
                if (ps.Length == 0) continue;

                try
                {
                    // (string, …)
                    if (ps[0].ParameterType == typeof(string))
                    {
                        var ctorArgs = new object?[ps.Length];
                        ctorArgs[0] = uassetPath;

                        bool ok = true;
                        for (int i = 1; i < ps.Length; i++)
                        {
                            var pt = ps[i].ParameterType;

                            if (pt == typeof(bool)) { ctorArgs[i] = hasUexp; continue; }
                            if (EngineVersion != null && pt == EngineVersion) { ctorArgs[i] = engineVer!; continue; }
                            if (CustomSerializationFlags != null && pt == CustomSerializationFlags) { ctorArgs[i] = csf!; continue; }
                            if (ObjectVersion != null && pt == ObjectVersion) { ctorArgs[i] = objVer!; continue; }
                            if (ObjectVersionUE5 != null && pt == ObjectVersionUE5) { ctorArgs[i] = objVer5!; continue; }
                            if (UsmapType != null && pt == UsmapType) { ctorArgs[i] = null; continue; } // ★ 不使用 usmap

                            // 其它未知参数，放弃这个重载
                            ok = false; break;
                        }
                        if (ok)
                        {
                            asset = ctor.Invoke(ctorArgs);
                            if (asset != null) break;
                        }
                    }

                    // (AssetBinaryReader, …)
                    if (asset == null && AssetBinaryReader != null && ps[0].ParameterType == AssetBinaryReader)
                    {
                        using var fs2 = File.OpenRead(uassetPath);
                        object? reader = null;

                        foreach (var rctor in AssetBinaryReader.GetConstructors())
                        {
                            var rps = rctor.GetParameters();
                            if (rps.Length >= 1 && rps[0].ParameterType == typeof(Stream))
                            {
                                var readerCtorArgs = new object?[rps.Length];
                                readerCtorArgs[0] = fs2;
                                for (int j = 1; j < rps.Length; j++)
                                {
                                    var rpt = rps[j].ParameterType;
                                    if (rpt.IsEnum) readerCtorArgs[j] = Enum.ToObject(rpt, 0);
                                    else if (rpt == typeof(long) || rpt == typeof(int)) readerCtorArgs[j] = 0;
                                    else readerCtorArgs[j] = null;
                                }
                                reader = rctor.Invoke(readerCtorArgs);
                                break;
                            }
                        }
                        if (reader == null) continue;

                        var ctorArgs2 = new object?[ps.Length];
                        ctorArgs2[0] = reader;

                        bool ok2 = true;
                        for (int i = 1; i < ps.Length; i++)
                        {
                            var pt = ps[i].ParameterType;
                            if (EngineVersion != null && pt == EngineVersion) { ctorArgs2[i] = engineVer!; continue; }
                            if (pt == typeof(bool)) { ctorArgs2[i] = hasUexp; continue; }
                            if (CustomSerializationFlags != null && pt == CustomSerializationFlags) { ctorArgs2[i] = csf!; continue; }
                            if (ObjectVersion != null && pt == ObjectVersion) { ctorArgs2[i] = objVer!; continue; }
                            if (ObjectVersionUE5 != null && pt == ObjectVersionUE5) { ctorArgs2[i] = objVer5!; continue; }
                            if (UsmapType != null && pt == UsmapType) { ctorArgs2[i] = null; continue; } // ★ 不使用 usmap

                            ok2 = false; break;
                        }
                        if (ok2)
                        {
                            asset = ctor.Invoke(ctorArgs2);
                            if (asset != null) break;
                        }
                    }
                }
                catch
                {
                    // 尝试下一个重载
                }
            }

            if (asset == null)
            {
                var sigs = string.Join("\n  ", uassetType.GetConstructors()
                    .Select(c => $"({string.Join(", ", c.GetParameters().Select(p => p.ParameterType.Name))})"));
                throw new MissingMethodException("未能匹配到可用 UAsset 构造函数。构造器有：\n  " + sigs);
            }

            // 精确选择 SerializeJson/SerializeJSON 重载
            var serMethods = uassetType.GetMethods(BindingFlags.Instance | BindingFlags.Public)
                .Where(m => (m.Name == "SerializeJson" || m.Name == "SerializeJSON")
                         && m.ReturnType == typeof(string))
                .ToArray();

            var ser = serMethods.FirstOrDefault(m =>
            {
                var p = m.GetParameters();
                return p.Length == 1 && p[0].ParameterType == typeof(bool);
            }) ?? serMethods.FirstOrDefault(m => m.GetParameters().Length == 0);

            if (ser == null)
            {
                var list = string.Join("\n  ", serMethods.Select(m => $"{m.Name}({string.Join(", ", m.GetParameters().Select(p => p.ParameterType.Name))})"));
                throw new MissingMethodException("未找到可用的 JSON 序列化方法。候选：\n  " + (list == "" ? "(无)" : list));
            }

            string json = ser.GetParameters().Length == 1
                ? (string)(ser.Invoke(asset, new object?[] { true }) ?? "{}")
                : (string)(ser.Invoke(asset, Array.Empty<object?>()) ?? "{}");

            var outPath = Path.ChangeExtension(uassetPath, ".json");
            File.WriteAllText(outPath, json);
            Console.WriteLine("OK -> " + outPath);
            return 0;
        }
        catch (Exception ex)
        {
            Console.Error.WriteLine("导出失败: " + ex.GetType().Name + " - " + ex.Message);
            return 1;
        }
    }
}
